from django.contrib import admin
from MyBlog.models import Post

class PostAdmin(admin.ModelAdmin):
    list_display = ('title', 'update', 'show', 'timestamp', 'topic')
    list_editable = ('title', 'show')
    list_filter = ('update', 'timestamp')
    list_display_links = ('update', )



admin.site.register(Post, PostAdmin)