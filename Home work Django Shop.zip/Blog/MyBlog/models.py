from django.db import models




def fields_topic():
    topic_fields = [
        ('joke', 'joke'),
        ('animals', 'тварини'),
        ('природа', 'nature')
    ]
    return topic_fields


class Post(models.Model):
    title = models.CharField(max_length=50)
    topic = models.CharField(max_length=30,
                             choices=fields_topic(),
                             default='')
    content = models.TextField()
    update = models.DateTimeField(auto_now=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    show = models.BooleanField(default=True)

    class Meta:
        ordering = ('-timestamp',)

    def get_show(self):
        if self.show:
            self.show = False
            self.save()


    def get_absolute_url(self):
        return f'/posts/detail/{self.id}'

    def get_blog_url(self):
        return f'/posts/'

    def __str__(self):
        return self.title
