from django.contrib import admin
from Shop.models import Shop

class ShopAdmin(admin.ModelAdmin):
    list_display = ('item', 'category', 'price', 'currency', 'website', 'update', 'timestamp')
    list_editable = ('item', )
    list_filter = ('category', 'price', )
    list_display_links = ('update', )





admin.site.register(Shop, ShopAdmin)
