from django.urls import path
from Shop.views import shop_main_page, item_category, item_detail, item_create, item_update, item_delete

app_name = 'Shop'
urlpatterns = [
    path('', shop_main_page, name = 'shop_page'),
    path('item/category/', item_category),
    path('item/detail/<int:id>/', item_detail, name = 'item_detail'),
    path('item/create/', item_create),
    path('item/update/', item_update),
    path('item/delete/', item_delete),


]