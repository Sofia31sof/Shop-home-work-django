from django.http import HttpResponse
from django.shortcuts import render, get_object_or_404, redirect

from Shop.models import Shop


def shop_main_page(request):
    queryset = Shop.objects.all()
    context = {
        'title': 'Shop items!!!',
        'items_list': queryset
    }
    return render(request, 'shop_list.html', context)


def item_category(request):
    queryset = Shop.objects.all()
    context = {
        'title': 'Shop items!!!',
        'items_list': queryset
    }
    return render(request, 'shop_category.html', context)




def item_detail(request, id = None):
    instance = get_object_or_404(Shop, id=id)
    context = {
        'title': 'Item detail',
        'object': instance
    }
    return render(request, 'item_detail.html', context)


def item_create(request):
    context = {
        'title': 'Item create!!!',
    }
    return render(request, 'post_list.html', context)


def item_update(request):
    context = {
        'title': 'Item update!!!',
    }
    return render(request, 'post_list.html', context)


def item_delete(request, id = None):
    instance = get_object_or_404(Shop, id=id)
    instance.delete()
    return redirect('Shop:shop_page')
