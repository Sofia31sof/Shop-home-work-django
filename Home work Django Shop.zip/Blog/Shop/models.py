from django.db import models


def categories():
    categories = [
        ('Fresh Produce', 'Fresh Produce'),
        ('Meat', 'Meat'),
        ('Seafood', 'Seafood'),
        ('Beverages', 'Beverages'),
        ('Alcohol', 'Alcohol')
    ]
    return categories


class Shop(models.Model):
    item = models.CharField(max_length=50)
    category = models.CharField(max_length=30,
                                choices=categories(),
                                default='')
    content = models.TextField()
    update = models.DateTimeField(auto_now=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    price = models.DecimalField(decimal_places=2, max_digits=4)
    currency = models.TextField(default='$')
    website = models.URLField(max_length=200)


    class Meta:
        ordering =('-timestamp',)

    def get_absolute_url(self):
        return f'/shop/item/detail/{self.id}'

    def __str__(self):
        return self.item
